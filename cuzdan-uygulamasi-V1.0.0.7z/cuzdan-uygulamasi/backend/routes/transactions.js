// backend/routes/transactions.js - TAM DÜZELTMİŞ VERSİYON
const express = require('express');
const Transaction = require('../models/Transaction');
const User = require('../models/User');
const auth = require('../middleware/auth');
const router = express.Router();

// Summary route (EN BAŞTA OLMALI)
router.get('/summary', auth, async (req, res) => {
  try {
    console.log('Getting summary for user:', req.user._id);
    const user = await User.findById(req.user._id);
    
    if (!user) {
      return res.status(404).json({ message: 'Kullanıcı bulunamadı' });
    }
    
    const income = await Transaction.aggregate([
      { $match: { userId: req.user._id, type: 'income' } },
      { $group: { _id: null, total: { $sum: '$amount' } } }
    ]);

    const expense = await Transaction.aggregate([
      { $match: { userId: req.user._id, type: 'expense' } },
      { $group: { _id: null, total: { $sum: '$amount' } } }
    ]);

    console.log('Summary calculated');
    res.json({
      balance: user.balance,
      totalIncome: income[0]?.total || 0,
      totalExpense: expense[0]?.total || 0
    });
  } catch (error) {
    console.error('Summary error:', error);
    res.status(500).json({ message: 'Sunucu hatası' });
  }
});

// Tek işlemi getir
router.get('/:id', auth, async (req, res) => {
  try {
    const { id } = req.params;
    console.log('Getting transaction:', id);
    
    if (id === 'summary') {
      return res.status(404).json({ message: 'İşlem bulunamadı' });
    }
    
    const transaction = await Transaction.findOne({ 
      _id: id, 
      userId: req.user._id 
    }).populate('toUserId', 'name email');

    if (!transaction) {
      return res.status(404).json({ message: 'İşlem bulunamadı' });
    }

    console.log('Transaction found');
    res.json(transaction);
  } catch (error) {
    console.error('Get single transaction error:', error);
    if (error.name === 'CastError') {
      return res.status(400).json({ message: 'Geçersiz işlem ID' });
    }
    res.status(500).json({ message: 'Sunucu hatası' });
  }
});

// Tüm işlemleri getir
router.get('/', auth, async (req, res) => {
  try {
    console.log('Getting transactions for user:', req.user._id);
    const transactions = await Transaction.find({ userId: req.user._id })
      .sort({ date: -1 })
      .populate('toUserId', 'name email');
    
    console.log('Found transactions:', transactions.length);
    res.json(transactions);
  } catch (error) {
    console.error('Get transactions error:', error);
    res.status(500).json({ message: 'Sunucu hatası', error: error.message });
  }
});

// Yeni işlem oluştur
router.post('/', auth, async (req, res) => {
  try {
    const { type, amount, description, category, toUserId } = req.body;
    console.log('Creating transaction:', { type, amount, description, category });

    const user = await User.findById(req.user._id);
    if (!user) {
      return res.status(404).json({ message: 'Kullanıcı bulunamadı' });
    }

    if (type === 'expense' && user.balance < amount) {
      return res.status(400).json({ message: 'Yetersiz bakiye' });
    }

    const transaction = new Transaction({
      userId: req.user._id,
      type,
      amount: parseFloat(amount),
      description,
      category,
      toUserId
    });

    if (type === 'income') {
      user.balance += parseFloat(amount);
    } else if (type === 'expense') {
      user.balance -= parseFloat(amount);
    }

    await transaction.save();
    await user.save();

    console.log('Transaction created successfully');
    res.status(201).json({
      message: 'İşlem başarılı',
      transaction,
      newBalance: user.balance
    });
  } catch (error) {
    console.error('Create transaction error:', error);
    res.status(500).json({ message: 'Sunucu hatası', error: error.message });
  }
});

// İşlemi güncelle
router.put('/:id', auth, async (req, res) => {
  try {
    const { id } = req.params;
    const { type, amount, description, category } = req.body;
    console.log('Updating transaction:', id, { type, amount, description, category });

    const transaction = await Transaction.findOne({ 
      _id: id, 
      userId: req.user._id 
    });

    if (!transaction) {
      return res.status(404).json({ message: 'İşlem bulunamadı' });
    }

    const oldType = transaction.type;
    const oldAmount = transaction.amount;

    const user = await User.findById(req.user._id);
    if (!user) {
      return res.status(404).json({ message: 'Kullanıcı bulunamadı' });
    }

    if (oldType === 'income') {
      user.balance -= oldAmount;
    } else if (oldType === 'expense') {
      user.balance += oldAmount;
    }

    transaction.type = type;
    transaction.amount = parseFloat(amount);
    transaction.description = description;
    transaction.category = category;

    if (type === 'income') {
      user.balance += parseFloat(amount);
    } else if (type === 'expense') {
      user.balance -= parseFloat(amount);
    }

    if (user.balance < 0) {
      if (oldType === 'income') {
        user.balance += oldAmount;
      } else if (oldType === 'expense') {
        user.balance -= oldAmount;
      }
      return res.status(400).json({ message: 'Yetersiz bakiye' });
    }

    await transaction.save();
    await user.save();

    console.log('Transaction updated successfully');
    res.json({
      message: 'İşlem güncellendi',
      transaction,
      newBalance: user.balance
    });
  } catch (error) {
    console.error('Update transaction error:', error);
    res.status(500).json({ message: 'Sunucu hatası', error: error.message });
  }
});

// İşlemi sil (DÜZELTİLDİ)
router.delete('/:id', auth, async (req, res) => {
  try {
    const { id } = req.params;
    console.log('Deleting transaction:', id);

    // İşlemi doğrudan sil ve kullanıcı kontrolü yap
    const transaction = await Transaction.findOneAndDelete({ 
      _id: id, 
      userId: req.user._id 
    });

    if (!transaction) {
      return res.status(404).json({ message: 'İşlem bulunamadı veya silme yetkiniz yok' });
    }

    // Kullanıcıyı bul
    const user = await User.findById(req.user._id);
    if (!user) {
      return res.status(404).json({ message: 'Kullanıcı bulunamadı' });
    }

    // İşlemi geri al
    if (transaction.type === 'income') {
      user.balance -= transaction.amount;
    } else if (transaction.type === 'expense') {
      user.balance += transaction.amount;
    }

    await user.save();

    console.log('Transaction deleted successfully');
    res.json({
      message: 'İşlem silindi',
      newBalance: user.balance
    });
  } catch (error) {
    console.error('Delete transaction error:', error);
    res.status(500).json({ message: 'Sunucu hatası', error: error.message });
  }
});

module.exports = router;