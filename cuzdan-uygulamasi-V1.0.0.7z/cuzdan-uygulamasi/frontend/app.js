// frontend/app.js
console.log('App.js loaded');

// API base URL
const API_BASE_URL = 'http://localhost:3000/api';

// Token kontrolü
function checkAuth() {
    const token = localStorage.getItem('token');
    const publicPages = ['index.html', 'login.html', 'register.html', '/'];
    const currentPage = window.location.pathname.split('/').pop() || 'index.html';
    
    console.log('Checking auth for page:', currentPage, 'Token exists:', !!token);
    
    if (!token && !publicPages.includes(currentPage)) {
        console.log('No token, redirecting to login');
        window.location.href = 'login.html';
        return false;
    }
    
    if (token && (currentPage === 'login.html' || currentPage === 'register.html')) {
        console.log('Token exists, redirecting to dashboard');
        window.location.href = 'dashboard.html';
        return false;
    }
    
    return true;
}

// API istekleri için yardımcı fonksiyon
async function apiRequest(endpoint, options = {}) {
    const token = localStorage.getItem('token');
    
    const config = {
        headers: {
            'Content-Type': 'application/json',
            ...options.headers
        },
        ...options
    };
    
    if (token) {
        config.headers.Authorization = `Bearer ${token}`;
    }
    
    try {
        console.log('API Request:', `${API_BASE_URL}${endpoint}`, config);
        const response = await fetch(`${API_BASE_URL}${endpoint}`, config);
        const data = await response.json();
        
        if (!response.ok) {
            throw new Error(data.message || 'Bir hata oluştu');
        }
        
        return data;
    } catch (error) {
        console.error('API error:', error);
        throw error;
    }
}

// Form verilerini objeye çevirme
function formDataToObject(formData) {
    const object = {};
    formData.forEach((value, key) => {
        object[key] = value;
    });
    return object;
}

// Para birimi formatlama
function formatCurrency(amount, currency = 'TRY') {
    return new Intl.NumberFormat('tr-TR', {
        style: 'currency',
        currency: currency
    }).format(amount);
}

// Tarih formatlama
function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('tr-TR', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    });
}

// Local storage işlemleri
const Storage = {
    set: (key, value) => {
        localStorage.setItem(key, JSON.stringify(value));
    },
    
    get: (key) => {
        try {
            return JSON.parse(localStorage.getItem(key));
        } catch {
            return null;
        }
    },
    
    remove: (key) => {
        localStorage.removeItem(key);
    }
};

// Sayfa yüklendiğinde auth kontrolü
document.addEventListener('DOMContentLoaded', function() {
    console.log('DOM loaded, checking auth');
    checkAuth();
});

// Global error handling
window.addEventListener('error', function(e) {
    console.error('Global error:', e.error);
});

// Promise rejection handling
window.addEventListener('unhandledrejection', function(e) {
    console.error('Unhandled promise rejection:', e.reason);
});

// Export functions
window.apiRequest = apiRequest;
window.formatCurrency = formatCurrency;
window.formatDate = formatDate;
window.Storage = Storage;