// backend/routes/payments.js
const express = require('express');
const Payment = require('../models/Payment');
const Transaction = require('../models/Transaction');
const User = require('../models/User');
const auth = require('../middleware/auth');
const router = express.Router();

// Tüm ödemeleri getir
router.get('/', auth, async (req, res) => {
  try {
    const payments = await Payment.find({ userId: req.user._id })
      .sort({ isPaid: 1, dueDate: 1 });
    
    res.json(payments);
  } catch (error) {
    res.status(500).json({ message: 'Sunucu hatası', error: error.message });
  }
});

// Yeni ödeme oluştur
router.post('/', auth, async (req, res) => {
  try {
    const { type, amount, description, category, dueDate } = req.body;

    const user = await User.findById(req.user._id);
    if (!user) {
      return res.status(404).json({ message: 'Kullanıcı bulunamadı' });
    }

    const payment = new Payment({
      userId: req.user._id,
      type,
      amount: parseFloat(amount),
      description,
      category,
      dueDate: new Date(dueDate)
    });

    await payment.save();

    res.status(201).json({
      message: 'Ödeme başarıyla oluşturuldu',
      payment
    });
  } catch (error) {
    res.status(500).json({ message: 'Sunucu hatası', error: error.message });
  }
});

// Ödemeyi güncelle
router.put('/:id', auth, async (req, res) => {
  try {
    const { id } = req.params;
    const { type, amount, description, category, dueDate } = req.body;

    const payment = await Payment.findOne({ 
      _id: id, 
      userId: req.user._id 
    });

    if (!payment) {
      return res.status(404).json({ message: 'Ödeme bulunamadı' });
    }

    payment.type = type;
    payment.amount = parseFloat(amount);
    payment.description = description;
    payment.category = category;
    payment.dueDate = new Date(dueDate);

    await payment.save();

    res.json({
      message: 'Ödeme başarıyla güncellendi',
      payment
    });
  } catch (error) {
    res.status(500).json({ message: 'Sunucu hatası', error: error.message });
  }
});

// Ödemeyi sil
router.delete('/:id', auth, async (req, res) => {
  try {
    const { id } = req.params;

    const payment = await Payment.findOne({ 
      _id: id, 
      userId: req.user._id 
    });

    if (!payment) {
      return res.status(404).json({ message: 'Ödeme bulunamadı' });
    }

    await payment.remove();

    res.json({
      message: 'Ödeme silindi'
    });
  } catch (error) {
    res.status(500).json({ message: 'Sunucu hatası', error: error.message });
  }
});

// Ödemeyi işle (ödendi olarak işaretle ve transaction olarak ekle)
router.put('/:id/process', auth, async (req, res) => {
  try {
    const { id } = req.params;
    const { paidDate } = req.body;

    const payment = await Payment.findOne({ 
      _id: id, 
      userId: req.user._id 
    });

    if (!payment) {
      return res.status(404).json({ message: 'Ödeme bulunamadı' });
    }

    if (payment.isPaid) {
      return res.status(400).json({ message: 'Bu ödeme zaten işlenmiş' });
    }

    const user = await User.findById(req.user._id);
    if (!user) {
      return res.status(404).json({ message: 'Kullanıcı bulunamadı' });
    }

    if (payment.type === 'debt' && user.balance < payment.amount) {
      return res.status(400).json({ message: 'Yetersiz bakiye' });
    }

    payment.isPaid = true;
    payment.paidDate = paidDate ? new Date(paidDate) : new Date();

    const transactionType = payment.type === 'debt' ? 'expense' : 'income';
    
    const transaction = new Transaction({
      userId: req.user._id,
      type: transactionType,
      amount: payment.amount,
      description: payment.description,
      category: payment.category,
      date: payment.paidDate
    });

    if (transactionType === 'income') {
      user.balance += payment.amount;
    } else if (transactionType === 'expense') {
      user.balance -= payment.amount;
    }

    payment.transactionId = transaction._id;

    await transaction.save();
    await payment.save();
    await user.save();

    res.json({
      message: 'Ödeme başarıyla işlendi',
      payment,
      transaction,
      newBalance: user.balance
    });
  } catch (error) {
    res.status(500).json({ message: 'Sunucu hatası', error: error.message });
  }
});

module.exports = router;