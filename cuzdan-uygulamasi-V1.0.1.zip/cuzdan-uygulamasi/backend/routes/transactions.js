// backend/routes/transactions.js
const express = require('express');
const Transaction = require('../models/Transaction');
const User = require('../models/User');
const auth = require('../middleware/auth');
const router = express.Router();

// Tüm işlemleri getir
router.get('/', auth, async (req, res) => {
  try {
    const transactions = await Transaction.find({ userId: req.user._id })
      .sort({ date: -1 });
    
    res.json(transactions);
  } catch (error) {
    res.status(500).json({ message: 'Sunucu hatası', error: error.message });
  }
});

// Tek işlem getir
router.get('/:id', auth, async (req, res) => {
  try {
    const { id } = req.params;
    console.log('Getting transaction:', id);
    
    const transaction = await Transaction.findOne({ 
      _id: id, 
      userId: req.user._id 
    });

    if (!transaction) {
      return res.status(404).json({ message: 'İşlem bulunamadı' });
    }

    console.log('Transaction found');
    res.json(transaction);
  } catch (error) {
    console.error('Get single transaction error:', error);
    res.status(500).json({ message: 'Sunucu hatası', error: error.message });
  }
});

// Yeni işlem oluştur
router.post('/', auth, async (req, res) => {
  try {
    const { type, amount, description, category, date } = req.body;

    const user = await User.findById(req.user._id);
    if (!user) {
      return res.status(404).json({ message: 'Kullanıcı bulunamadı' });
    }

    if (type === 'expense' && user.balance < amount) {
      return res.status(400).json({ message: 'Yetersiz bakiye' });
    }

    const transaction = new Transaction({
      userId: req.user._id,
      type,
      amount: parseFloat(amount),
      description,
      category,
      date: date ? new Date(date) : new Date()
    });

    if (type === 'income') {
      user.balance += parseFloat(amount);
    } else if (type === 'expense') {
      user.balance -= parseFloat(amount);
    }

    await transaction.save();
    await user.save();

    res.status(201).json({
      message: 'İşlem başarılı',
      transaction,
      newBalance: user.balance
    });
  } catch (error) {
    res.status(500).json({ message: 'Sunucu hatası', error: error.message });
  }
});

// İşlemi güncelle
router.put('/:id', auth, async (req, res) => {
  try {
    const { id } = req.params;
    const { type, amount, description, category, date } = req.body;

    const transaction = await Transaction.findOne({ 
      _id: id, 
      userId: req.user._id 
    });

    if (!transaction) {
      return res.status(404).json({ message: 'İşlem bulunamadı' });
    }

    const oldType = transaction.type;
    const oldAmount = transaction.amount;

    const user = await User.findById(req.user._id);
    if (!user) {
      return res.status(404).json({ message: 'Kullanıcı bulunamadı' });
    }

    if (oldType === 'income') {
      user.balance -= oldAmount;
    } else if (oldType === 'expense') {
      user.balance += oldAmount;
    }

    transaction.type = type;
    transaction.amount = parseFloat(amount);
    transaction.description = description;
    transaction.category = category;
    transaction.date = date ? new Date(date) : new Date();

    if (type === 'income') {
      user.balance += parseFloat(amount);
    } else if (type === 'expense') {
      user.balance -= parseFloat(amount);
    }

    if (user.balance < 0) {
      if (oldType === 'income') {
        user.balance += oldAmount;
      } else if (oldType === 'expense') {
        user.balance -= oldAmount;
      }
      return res.status(400).json({ message: 'Yetersiz bakiye' });
    }

    await transaction.save();
    await user.save();

    res.json({
      message: 'İşlem güncellendi',
      transaction,
      newBalance: user.balance
    });
  } catch (error) {
    res.status(500).json({ message: 'Sunucu hatası', error: error.message });
  }
});

// İşlemi sil
router.delete('/:id', auth, async (req, res) => {
  try {
    const { id } = req.params;

    const transaction = await Transaction.findOne({ 
      _id: id, 
      userId: req.user._id 
    });

    if (!transaction) {
      return res.status(404).json({ message: 'İşlem bulunamadı' });
    }

    const user = await User.findById(req.user._id);
    if (!user) {
      return res.status(404).json({ message: 'Kullanıcı bulunamadı' });
    }

    if (transaction.type === 'income') {
      user.balance -= transaction.amount;
    } else if (transaction.type === 'expense') {
      user.balance += transaction.amount;
    }

    await transaction.remove();
    await user.save();

    res.json({
      message: 'İşlem silindi',
      newBalance: user.balance
    });
  } catch (error) {
    res.status(500).json({ message: 'Sunucu hatası', error: error.message });
  }
});

// Toplam bakiye ve istatistikler
router.get('/summary', auth, async (req, res) => {
  try {
    const user = await User.findById(req.user._id);
    
    const income = await Transaction.aggregate([
      { $match: { userId: req.user._id, type: 'income' } },
      { $group: { _id: null, total: { $sum: '$amount' } } }
    ]);

    const expense = await Transaction.aggregate([
      { $match: { userId: req.user._id, type: 'expense' } },
      { $group: { _id: null, total: { $sum: '$amount' } } }
    ]);

    res.json({
      balance: user.balance,
      totalIncome: income[0]?.total || 0,
      totalExpense: expense[0]?.total || 0
    });
  } catch (error) {
    res.status(500).json({ message: 'Sunucu hatası' });
  }
});

module.exports = router;