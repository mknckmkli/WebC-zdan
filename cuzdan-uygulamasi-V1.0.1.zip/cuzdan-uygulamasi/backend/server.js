// backend/server.js - TAM DÜZELTME
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const path = require('path');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Debug middleware
app.use((req, res, next) => {
  console.log(`🔍 ${new Date().toISOString()} - ${req.method} ${req.path}`);
  next();
});

// MongoDB bağlantısı
mongoose.connect(process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/walletapp', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
})
.then(() => console.log('MongoDB bağlantısı başarılı'))
.catch(err => {
  console.log('MongoDB bağlantı hatası:', err);
  process.exit(1);
});

// API Routes - ÖNCE TANIMLA
console.log('🚀 Loading API routes...');
app.use('/api/auth', require('./routes/auth'));
app.use('/api/transactions', require('./routes/transactions'));

// Health check
app.get('/api/health', (req, res) => {
  res.json({ 
    message: 'Cüzdan Uygulaması API çalışıyor!', 
    status: 'OK',
    timestamp: new Date().toISOString()
  });
});

// Favicon ignore
app.get('/favicon.ico', (req, res) => {
  res.status(204).end();
});

// Statik dosyalar - frontend klasörünü doğru şekilde serve et
console.log('📁 Serving static files from:', path.join(__dirname, '../frontend'));
app.use(express.static(path.join(__dirname, '../frontend')));

// Ana route - index.html
app.get('/', (req, res) => {
  console.log('🏠 Serving index.html');
  res.sendFile(path.join(__dirname, '../frontend/index.html'));
});

// SPA routing - tüm diğer route'lar için frontend dosyasını serve et
app.get('*', (req, res) => {
  console.log('🔄 SPA routing for:', req.path);
  
  // API istekleri için 404 döndür
  if (req.path.startsWith('/api/')) {
    console.log('❌ API 404 for:', req.path);
    return res.status(404).json({ 
      message: 'API endpoint bulunamadı',
      path: req.path
    });
  }
  
  // Diğer tüm istekler için frontend index.html
  console.log('📁 Serving frontend for:', req.path);
  res.sendFile(path.join(__dirname, '../frontend/index.html'), (err) => {
    if (err) {
      console.log('📁 File serve error:', err);
      // Dosya bulunamazsa index.html serve et
      res.sendFile(path.join(__dirname, '../frontend/index.html'));
    }
  });
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`🚀 Sunucu http://localhost:${PORT} portunda çalışıyor`);
  console.log(`📝 API Health Check: http://localhost:${PORT}/api/health`);
});